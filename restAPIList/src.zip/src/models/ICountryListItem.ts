export interface ICountryListItem {
    Id: string;
    Title: string;
  }