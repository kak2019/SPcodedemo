/* tslint:disable */
require("./HelloWorld.module.css");
const styles = {
  helloWorld: 'helloWorld_77b1b046',
  container: 'container_77b1b046',
  row: 'row_77b1b046',
  column: 'column_77b1b046',
  'ms-Grid': 'ms-Grid_77b1b046',
  title: 'title_77b1b046',
  subTitle: 'subTitle_77b1b046',
  description: 'description_77b1b046',
  button: 'button_77b1b046',
  label: 'label_77b1b046',
  list: 'list_77b1b046',
  item: 'item_77b1b046'
};

export default styles;
/* tslint:enable */